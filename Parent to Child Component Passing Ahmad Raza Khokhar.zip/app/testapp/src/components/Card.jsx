import React from 'react'
export default function Card({title, desc, imgSrc, link}) {
  return (
<>
     <div className="cardBox">
        <img src={imgSrc} alt="-" className="cardImage" />
        <div className="centerItems">
        <h2 className="cardTitle">{title}</h2>
        <h5 className="cardDesc">{desc}</h5>
        <a href={link}><button type="submit" className="btnSub" title='Visit'>Visit</button></a>
        </div>
     </div>
</>
  )
};

