import React from 'react'

export default function About() {
  return (

    <div>
        <br/>
        <br/>
      <div className="media">
  <img className="align-self-start profile" src="./images/ark.jpeg" alt="Generic placeholder image"/>
  <div className="body">
    <h5 className="mt-1 fw-bold coloring">Ahmad Raza Khokhar</h5>
    <pre className='containerText cardDesc'>
👋 Hello! I'm Ahmad Raza Khokhar, an Expert MERN Stack Developer based in Lahore. I'm dedicated to crafting <br />
seamless web experiences that harmoniously blend technical expertise with creative ingenuity. <br />
<br />
🚀 <b>Skill Set and Services:</b><br />
My expertise covers a comprehensive range of technologies, including:<br />
- 🍃 MongoDB for robust data management<br />
- ⚛️ Harnessing the dynamic capabilities of React JS<br />
- 🚀 Utilizing Express JS for streamlined web applications<br />
- 🌐 Navigating Node JS to power up backend functionalities<br />
- ✨ Crafting interactive interfaces using JSX, HTML, CSS, and Bootstrap<br />
- 🛒 Developing user-friendly experiences with PHP, WordPress, and Shopify<br />
<br />
🧰 <b>Technical Background:</b><br />
My journey commenced as a Junior MERN Stack Developer at Nexskill - Be Productive, where I actively <br />contribute to building powerful web applications. Drawing from my experiences on platforms like Fiverr and
<br />Upwork,
I bring a versatile skill set to the table. My educational foundation includes an Associate's degree <br />in Computer Software Engineering, where I delved deeply into languages like React and Node JS. I've undertaken <br />projects
that emulate the likes of YouTube, Facebook, and Instagram.<br />
<br />
🎓 <b>Educational Milestones & Certifications:</b><br />
- Intermediate in Pre-Engineering from loh Qalam Institute of Science<br />
- Matriculation in Computer Science from DHA Senior School for Boys<br />
- Diploma of WEB Designing in Computer Science from Technical Vocational Training Centre<br />
- Diploma of Computer Applications in Computer Science from Technical Vocational Training Academy<br />
- Currently pursuing an Associate's degree in Computer Software Engineering from Nexskill<br />
<br />
🏆 <b>Certification Highlights:</b><br />
- MERN Stack Developer Certification (Nexskill)<br />
- Responsive Web Design from freeCodeCamp<br />
- Front End Development Libraries from freeCodeCamp<br />
- PHP Developer from W3docs.com<br />
- Introduction to Programming Using HTML and CSS from W3docs.com<br />
- CSS Expert from W3docs.com<br />
- Python Beginner from ITRONIX SOLUTION<br />
<br />
🌟 <b>Why Collaborate With Me:</b><br />
My unwavering commitment to delivering exceptional solutions, combined with my relentless pursuit of continuous <br />
learning, positions me as a valuable asset to any project. From crafting polished websites to optimizing user<br /> interactions,
I excel at transforming concepts into functional code.<br />
<br />
📧 <b>Let's Connect:</b><br />
Feel free to reach out at ahmadrazawebexpert@gmail.com or +923008039275. Let's initiate a dialogue about how<br /> my skills
can elevate your upcoming ventures!<br />
<br />
Best Regards<br />
Ahmad Raza Khokhar.<br />
    </pre>
  </div>
</div>
    </div>
  )
}
