import React from 'react'

export default function Main() {
  return (
 
 <div className='bg'   >
        {/* link to accounts  */}
            <div className="container" >
       <a href="https://www.facebook.com/ahmadrazakhokhar786"> <img src="./images/facebook-logo.ico" alt="logo" className='logos' title='Facebook'/></a>
       <a href="https://www.instagram.com/mr_ahmad_70"> <img src="./images/instagram-logo.ico" alt="logo" className='logos' title='Instagram'/></a>
       <a href="https://github.com/mrahmad70"> <img src="./images/github-logo.ico" alt="logo" className='logos' title='Github'/></a>
       <a href='https://wa.me/message/UFORYZOS5RRBO1'> <img src="./images/whatsapp-logo.ico" alt="logo" className='logos' title='+923008039275'/></a>
       <a href="https://www.linkedin.com/in/ahmad-raza-/"> <img src="./images/linkedin-logo.ico" alt="logo" className='logos' title='LinkedIn'/></a>
       <a href="https://www.tiktok.com/@mr_ahmad_70"> <img src="./images/tiktok-logo.ico" alt="logo" className='logos' title='TikTok'/></a>
       <a href=""> <img src="./images/youtube-logo.ico" alt="logo" className='logos' title='Youtube'/></a>
    </div>
    {/* background wallpaper */}
      <img src="./images/bg.jpg" alt="bg" className="bgImage" />
    </div>
  )
}
