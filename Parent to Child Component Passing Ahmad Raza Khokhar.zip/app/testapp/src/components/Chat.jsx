import React from 'react'

export default function Chat() {
  return (
    <div>
      This Is Chat Component
    </div>
  )
}
