import './App.css';
import Navbar from './components/navbar';
import Card from './components/Card'
import React, {useState} from 'react'
function App() {
    const[name, setName] = useState('Ahmad');
    function abc(){
      setName('Ali');
    }
  return (
    <>
 
    <Navbar/>
    <div className='flex'>
    <Card
    title = 'Full Stack Website'
    imgSrc='./images/mern.png'
    desc = 'If you want a seamless and responsive Full Stack website  with proper backEnd & frontEnd  hit the button below!'
    link = 'https://www.upwork.com/services/product/development-it-algorithm-based-full-stack-website-and-theme-building-1694270939925200896?ref=project_share&tier=1'
    />
        <Card
    title = 'E-Commerce Store'
    imgSrc='./images/7.png'
    desc = 'If you want a clean and responsive E-Commerce Store website  hit the button below!'
    link = 'https://www.upwork.com/services/product/development-it-e-commerce-store-website-webapp-js-logic-1695523292029726720?ref=project_share&tier=1'
    />
        <Card
    title = 'Ahmad Raza Khokhar'
    imgSrc='./images/Ahmad Raza ..jpg'
    desc = 'If you want to see my coding skills and repositories, hit the button below!'
    link = 'https://github.com/mrahmad70'
    />
        <Card
    title = 'Word Press Website'
    imgSrc='./images/I will create you amazing.png'
    desc = 'If you want a clean and responsive wordpress website  hit the button below!'
    link = 'https://www.upwork.com/services/product/development-it-a-wordpress-website-along-with-html-css-1618369019406229504?ref=project_share&tier=2'
    />
        <Card
    title = 'Web Design Course'
    imgSrc='./images/Website & webapp course 1.png'
    desc = 'If you want to get a certified course of HTML, CSS, JSX, JS & React JS  hit the button below!'
    link = 'https://www.upwork.com/services/product/development-it-e-commerce-store-website-webapp-js-logic-1695523292029726720?ref=project_share&tier=1'
    />
    </div>
  <h3 className='tr'>Click The Button to Change</h3>
<button onClick={abc} className='useState'>{name}</button>
    </>
      );
}

export default App;
